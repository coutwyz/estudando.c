# Lista de Exercicios - Logica de Programacao em C

Resolucao da lista de exercicios em linguagem C. Cada questao fica em uma pasta com o arquivo `main.c`.

## Como compilar e executar

```
gcc main.c -o programa
./programa
```

No Windows, execute com `programa.exe`.

## Questoes

### Parte I - Algoritmos Sequenciais

- Questao 01 - Saudacao
- Questao 02 - Soma de dois numeros
- Questao 03 - Quatro operacoes
- Questao 04 - Media do aluno
- Questao 05 - Area do retangulo
- Questao 06 - Area do circulo
- Questao 07 - Conversao de temperatura
- Questao 08 - Salario mensal
- Questao 09 - Consumo de combustivel
- Questao 10 - Valor da compra

### Parte II - Estruturas Condicionais

- Questao 11 - Maior de idade
- Questao 12 - Numero positivo ou negativo
- Questao 13 - Numero par ou impar
- Questao 14 - Maior entre dois numeros
- Questao 15 - Maior entre tres numeros
- Questao 16 - Situacao academica
- Questao 17 - Desconto na compra
- Questao 18 - Faixa etaria
- Questao 19 - Calculo do IMC
- Questao 20 - Calculadora

### Parte III - Estruturas de Repeticao

- Questao 21 - Contagem crescente
- Questao 22 - Contagem regressiva
- Questao 23 - Numeros pares
- Questao 24 - Tabuada
- Questao 25 - Soma de 1 ate N
- Questao 26 - Media da turma
- Questao 27 - Aprovados e reprovados
- Questao 28 - Maior numero
- Questao 29 - Senha
- Questao 30 - Caixa eletronico

### Parte IV - Desafios

- Questao 31 - Posto de combustivel
- Questao 32 - Sistema de estacionamento
- Questao 33 - Eleicao
- Questao 34 - Sistema de vendas
- Questao 35 - Sistema academico

### Desafio Final

- Desafio Final - Sistema de pedidos de uma lanchonete
